
<?php

//echo "csv_read0.php<br>reads file then prints result on screen.<br>";

//echo str_replace(", ", "", "123, ,333, ,555");

$fn0 = fopen("0000.csv", "r") or die("Unable to open file!");
$data0 = fread($fn0,filesize("0000.csv"));
fclose($fn0);

$fn1 = fopen("unknown_space.txt", "r") or die("Unable to open file!");
$us0 = fread($fn1,filesize("unknown_space.txt"));
fclose($fn1);

$data1 = explode("\r\n", $data0);
$data2 = "";

for ($i=0;$i<count($data1);$i++){
	$data2 = $data2.$data1[$i].",";
}

echo $data2."<br>---<br>";

$data3 = explode($us0, $data2);
$data4 = "";

for ($i=0;$i<count($data3);$i++){
	$data4 = $data4.$data3[$i].",";
}

$data5 = str_replace(",,,", "", $data4);
echo $data5;

$fo2 = fopen("0000.csv2", "w");
fwrite($fo2, $data5);
fclose($fo2);

/*
$data2 = "123-4444-55-3333-6-77-8";
$data3 = explode("-", $data2);

$i0_end = count($data3);

for ($i0=0;$i0<$i0_end;$i0++){ 
	echo $data3[$i0]."<br>"; 
}
*/

?>
