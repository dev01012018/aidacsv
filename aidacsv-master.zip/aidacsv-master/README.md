# aidacsv
This project is for converting AIDA's simulation output data format to CSV. AIDA: www.2aida.org. The CSV output can also be stored in a MySQL database which has the structure described in the PHP code provided.
