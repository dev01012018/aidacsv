<?php

echo "csv_read1.php<br>reads \"input.2aida\" file then saves it into \"0000.csv\" output format.<br>";
echo "<br>".decimal2time_converter("12")."<br>";

$fn0 = fopen("input.2aida", "r") or die("Unable to open file!");
$data0 = fread($fn0,filesize("input.2aida"));
fclose($fn0);

$fn1 = fopen("undecoded_space.txt", "r") or die("Unable to open file!");
$us0 = fread($fn1,filesize("undecoded_space.txt"));
fclose($fn1);

$data1 = explode("\r\n", $data0);
$data1 = str_replace($us0,",",$data1);
$data2 = "";

for ($i=0;$i<count($data1);$i++){
	$data2 = str_replace(/*$us0*/" ",",",$data2.$data1[$i].",");
	//echo "<br>\$data2@i=".$i."=".$data2."<br>";
}

echo "\$data2=".$data2;//input as read from file
$data3 = explode(",",$data2);
$data4 = "";

$toggler = 1;
for ($i=0;$i<count($data3)-2;$i++){
	if ($i==0){$data3[$i]="00:00";$toggler=!toggler;}else{
	if ($toggler){$data3[$i] = decimal2time_converter($data3[$i]);}$toggler = !$toggler;}
	echo "<br>\$data3[".$i."]=".$data3[$i]."<br>";
	$data4 = $data4.$data3[$i].",";
}
$data4 = rtrim($data4,",");
//echo "<br>\$data4=".$data4."<br>";

$fo2 = fopen("0000.csv", "w");
fwrite($fo2, $data4);
fclose($fo2);

//=========================== END OF RUNNING CODE ====================================================

function decimal2time_converter($ip){
	$datax = explode(".",$ip);
	if (count($datax)<2){$datax[1]="00";}
	switch($datax[1]){
		case "00": return $datax[0].":00";
		case "25": return $datax[0].":15";
		case "5": return $datax[0].":30";
		case "75": return $datax[0].":45";
	}
}

?>
