<?php

//======================================= PHASE0 =================================================
echo "<br>#### PHASE0: META & TESTING ####<br>";
echo "By AEJ EST 2010(c). implemented by: YAS<br>";
echo "csv_read2.php<br>reads \"input.2aida\" file then fills 1 second linearly interpolated data";
echo "... then saves it to \"0000.csv\" output format.<br>";
echo "... the data entered was intended to interpolate www.2aida.org's outputs<br>";
//echo "<br>".decimal2time_converter("12")."<br>";//passed on 31OCT2017 YAS
//echo "<br>tti=".time_to_int("00:00:60")."<br>";//passed on 31OCT2017 YAS
//echo "<br>flif=".find_linear_interpolation_fraction(1,0.75)."<br>";//light test passed on 31OCT2017 YAS
//echo "<br>fli=".find_linear_interpolation(1,2,1,0.5)."<br>";//light test passed on 31OCT2017 YAS
//echo "<br>tsas=".time_string_add_seconds("12:00:00",5)."<br>";//light test passed on 01NOV2017 YAS

//======================================= PHASE1 =================================================
// passed on 31OCT2017 YAS
echo "<br>#### PHASE1: FILE LOADING AND PREPARATION OF DATA INTO AN ARRAY ####<br>";

$fn0 = fopen("input.2aida", "r") or die("Unable to open file!");
$data0 = fread($fn0,filesize("input.2aida"));
fclose($fn0);

$fn1 = fopen("undecoded_space.txt", "r") or die("Unable to open file!");
$us0 = fread($fn1,filesize("undecoded_space.txt"));
fclose($fn1);

$data1 = explode("\r\n", $data0);
$data1 = str_replace($us0,",",$data1);
$data2 = "";

for ($i=0;$i<count($data1);$i++){
	$data2 = str_replace(/*$us0*/" ",",",$data2.$data1[$i].",");
	//echo "<br>\$data2@i=".$i."=".$data2."<br>";//test line
}

//echo "\$data2=".$data2;//input as read from file//test line
$data3 = explode(",",$data2);
$data4 = "";

$toggler = 1;
for ($i=0;$i<count($data3)-2;$i++){
	if ($i==0){$data3[$i]="00:00:00";$toggler=!$toggler;}else{
	if ($toggler){$data3[$i] = decimal2time_converter($data3[$i]);}$toggler = !$toggler;}
	//echo "<br>\$data3[".$i."]=".$data3[$i]."<br>";//test line
	$data4 = $data4.$data3[$i].",";
}
$data4 = rtrim($data4,",");

//$data4 = array_dblidx_to_line($data3);
//echo "<br>\$data4=".$data4."<br>";//test line
echo "<br>>>>> PHASE1 END >>>><br>";
//=========================== SECOND BY SECOND INTERPOLATION =========================================
echo "<br>#### PHASE2: SECOND BY SECOND INTERPOLATION ####<br>";

$toggler = 1;
$y0=0;$y1=0;$x0=0;$x1=0;
$data4 = "";
//each 8 counts of i makes an hour of seconds interpolated data
//if you would like to cut out a certain hour or hours of data from aida's data taken in the array data3...
//... please calculate the location of the hour/hours required within the bulk of input data
$start_hour_idx = 0;
$end_hour_idx = 2;
$start_idx0 = $start_hour_idx;//index in hours
$end_idx0 = 8 * $end_hour_idx;

for ($i=$start_idx0;$i<$end_idx0/*count($data3)-2-2*/;$i=$i+2){
	if ($toggler){
		//echo "<br>toggler of phase3 i=".$i."<br>";//test_line
		//echo "<br>data3[i]=".$data3[$i]."<br>";//test line
		$x0=time_to_int($data3[$i+2])-time_to_int($data3[$i]);
		//echo "<br>x0=".$x0."<br>";
		$y0=$data3[$i+1];$y1=$data3[$i+3];}
		
	//we know that the input data is in 15 min intervals. fixed - hard coded.
	for ($i1=0;$i1<60*15*2;$i1=$i1+2){
		$var_idx = $i/2*60*15*2 + $i1;
		//echo "<br>var_idx=".$var_idx."<br>";//test line
		$time1 = explode($data3[$i],":");
		
		$x1 = $i1/2;
		//echo "<br>NEW FIND_LINEAR_INTERPOLATION: ".$y0."|".$y1."|".$x0."|".$x1."<br>";//test line
		//echo "<br>THE TIME TO ADD TO data3[".$i."]:".$data3[$i]." = ".$i1/(2)." = ".seconds2hhmmss($i1/(2))."<br>";
		$data4[$var_idx] = time_string_add_seconds($data3[$i],$i1/2);
		$data4[$var_idx+1] = find_linear_interpolation($y0,$y1,$x0,$x1);
		//echo "<br>RESULT=".$data4[$var_idx].",".$data4[$var_idx+1]."<br>";//test line
		}
	$toggler = !$toggler;
}

//$data5 = array_dblidx_to_line($data4);
//$toggler = 1;
$data5 = "";
for ($i=0;$i<count($data4)-2;$i++){
	/*
	if ($i==0){$data4[$i]="00:00:00";$toggler=!$toggler;}else{
	if ($toggler){$data4[$i] = decimal2time_converter($data3[$i]);}$toggler = !$toggler;}
	//echo "<br>\$data3[".$i."]=".$data3[$i]."<br>";//test line
	*/
	$data5 = $data5.$data4[$i].",";
}

echo "<br>>>>> PHASE2 END >>>><br>";

$data5 = rtrim($data5,",");
echo "<br>FINAL DATA AT ".date("Y-m-d H:i:s")." = ".$data5."<br>";

$fo2 = fopen("0000.csv", "w");
fwrite($fo2, $data5);
fclose($fo2);

//=========================== END OF RUNNING CODE ====================================================

// returns the linear interpolated value (y) between two values (y0,y1). the two values are
// (x0) units of distance from each other.
// (y) is (x1) units of distance from y0 (units of distance can be time, length, speed ... etc)
function find_linear_interpolation($y0,$y1,$x0,$x1){
	$lif0 = find_linear_interpolation_fraction($x0,$x1);
	//echo "<br>\$lif0=".$lif0."<br>";
	return ($y0 + (($y1-$y0)*$lif0));
}

//This is a horizontal (timeline/distance...x-axis) linear fraction. As most interpolation plots are precieved!
function find_linear_interpolation_fraction($x0,$x1){
	return (1-(($x0-$x1)/$x0));
}

//parts of a day
function time_to_int($t0){
	//echo "<br>NEW TIME_TO_INT : ".$t0."<br>";
	$a0 = explode(":",$t0);
	//echo "<br>time_to_int(".$t0.")-->".$a0[0]."|".$a0[1]."|".$a0[2]."<br>";
	//$v0 = ($a0[0] / 24.00)+($a0[1] / (60 * 24.00)) + ($a0[2] / (60 * 60 * 24.00));
	$v0 = (int)$a0[0]*60*60 + (int)$a0[1]*60 + (int)$a0[2];
	//echo "<br>".$v0."<br>";
	return $v0;
}

//entering negative integer values will subtract, parts of seconds are rounded up
//an example of 23:59:00 + 60 seconds will be converted to 00:00:00
//an example of 23:59:00 + 120 seconds will be converted to 00:01:00
function time_string_add_seconds($time_string, $seconds){
	$seconds2 = $seconds;
	while ($seconds2 >= 24*60*60){
		if ($seconds2 == 24*60*60){return $time_string;}
		$seconds2 = $seconds2 - 24*60*60;
		//echo "<br>seconds2=".$senods2."<br>";//test line
		}
		
	$time1 = explode(":",$time_string);
	if (count($time1)<3){return $time_string;}//bad length, just return the same input
	$h0 = (int)$time1[0];$m0=(int)$time1[1];$s0=(int)$time1[2];
	//echo "<br>add_seconds to (hh:mm:ss): ".$h0.":".$m0.":".$s0."<br>";//test line
	//echo "<br>seconds to be added= ".$seconds."<br>";
	$h1 = floor($seconds / (24 * 60)) + $h0;
	$hm1 = $seconds - ($h1 % (24 * 60));//modulus in seconds
	if ($h1 >= 24){$h1 = $h1 - 24;}
	$m1 = floor($hm1 / 60) + $m0;
	if ($m1 >= 60){$m1 = $m1 - 60; $h1 = $h1 + 1;}
	if ($h1 >= 24){$h1 = $h1 - 24;}
	$mm1 = ($hm1 + $m1 * 60) % 60;//modulus in seconds
	$s1 = round($mm1) + $s0;
	if ($s1 >= 60){$s1 = $s1 - 60; $m1 = $m1 + 1;}
	if ($m1 >= 60){$m1 = $m1 - 60; $h1 = $h1 + 1;}
	if ($h1 >= 24){$h1 = $h1 - 24;}
	
	//echo "<br>mod hm1=".$hm1.", mod mm1=".$mm1."<br>";//test line
	
	if (strlen($h1) < 2){ $h1 = "0".$h1;}
	if (strlen($m1) < 2){ $m1 = "0".$m1;}
	if (strlen($s1) < 2){ $s1 = "0".$s1;}
	return $h1.":".$m1.":".$s1;
}

//AIDA formatted decimal time converter to hh:mm:ss format
function decimal2time_converter($ip){
	if ($ip == "24"){return "00:00:00";}
	if ($ip == "0"){return "00:00:00";}
	$datax = explode(".",$ip);
	if (strlen($datax[0])<2){ $datax[0]="0".$datax[0];}
	if (count($datax)<2){return $datax[0].":00:00";}
	while ((int)$datax[0] >= 24){$datax[0]=(string)((int)$datax[0]-24);}//should be transferred into the next day calender addition
	switch($datax[1]){
		case "00": return $datax[0].":00:00";
		case "25": return $datax[0].":15:00";
		case "5": return $datax[0].":30:00";
		case "75": return $datax[0].":45:00";
	}
}

//value of time in seconds converted to hh:mm:ss format
//time over 23:59:59 will be cut and rewinded fit the range of 00:00:00->23:59:59
//the excess to be carried out as days/months/years can be taked from the $hm1 modulus
function seconds2hhmmss($ip){
	$h1 = floor($ip / (24 * 60));
	$hm1 = $ip - ($h1 * 24 * 60);//modulus in seconds
	if ($h1 >= 24){$h1 = $h1 - 24;}//cut days can be taken from hear to days/months/years
	$m1 = floor($hm1 / 60);$mm1 = $hm1 - $m1 * 60;//modulus in seconds
	$s1 = round($mm1);
	return $h1.":".$m1.":".$s1;
}

//a double index array a0,b0,a1,b1,a2,b2... is to be written in a single line separated by commas (CSV)
//the first value is time, the next is glucose level or any other generic decimal/float data value
function array_dblidx_to_line($ip){
	$op = "";
	$toggler = 1;
	for ($i=0;$i<count($ip)-2;$i++){
		if ($i==0){$ip[$i]="00:00:00";$toggler=!$toggler;}else{
		if ($toggler){$ip[$i] = decimal2time_converter($ip[$i]);}$toggler = !$toggler;}
		//echo "<br>\$ip[".$i."]=".$ip[$i]."<br>";//test line
		$op = $op.$ip[$i].",";
	}
	$op = rtrim($op,",");
	return $op;
}

?>
